package org.formation.dao;

import org.formation.model.Item;


public interface ItemsDao extends EntityDao<Item> {
	
}
