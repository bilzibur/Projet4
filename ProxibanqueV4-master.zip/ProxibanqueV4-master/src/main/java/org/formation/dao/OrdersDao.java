package org.formation.dao;

import org.formation.model.Order;

public interface OrdersDao extends EntityDao<Order>{
	
}
